/*
 Navicat Premium Data Transfer

 Source Server         : local_mariadb
 Source Server Type    : MariaDB
 Source Server Version : 110206 (11.2.6-MariaDB-ubu2204)
 Source Host           : 127.0.0.1:3306
 Source Schema         : usptodb

 Target Server Type    : MariaDB
 Target Server Version : 110206 (11.2.6-MariaDB-ubu2204)
 File Encoding         : 65001

 Date: 22/10/2026 14:41:03
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for accounts
-- ----------------------------
DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(191) NOT NULL,
  `password` varchar(512) NOT NULL,
  `priority` smallint(6) NOT NULL DEFAULT 100,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_used_at` datetime DEFAULT NULL,
  `success_login_count` int(10) unsigned NOT NULL DEFAULT 0,
  `failed_login_count` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `2fa_secret` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_accounts_username` (`username`),
  KEY `idx_accounts_priority_active` (`is_active`,`priority`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records of accounts
-- ----------------------------
BEGIN;
INSERT INTO `accounts` (`id`, `username`, `password`, `priority`, `is_active`, `last_used_at`, `success_login_count`, `failed_login_count`, `created_at`, `updated_at`, `2fa_secret`) VALUES (1, 'ingen.nice@gmail.com', 'Ya_ali^madd#110', 100, 1, '2026-10-01 13:21:51', 19, 4, '2026-09-17 12:11:38', '2026-10-01 13:21:51', 'otpauth://totp/MyUSPTO:ingen.nice%40gmail.com?secret=YMUGUPDEMRKTNDYO&issuer=MyUSPTO');
COMMIT;

-- ----------------------------
-- Table structure for files
-- ----------------------------
DROP TABLE IF EXISTS `files`;
CREATE TABLE `files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url_id` int(10) unsigned NOT NULL,
  `file_name` varchar(512) NOT NULL,
  `expected_size_bytes` bigint(20) unsigned DEFAULT NULL,
  `actual_size_bytes` bigint(20) unsigned DEFAULT NULL,
  `downloaded_path` varchar(1024) DEFAULT NULL,
  `status` enum('registered','downloading','downloaded','verified_healthy','size_mismatch','failed') NOT NULL DEFAULT 'registered',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_files_url_filename` (`url_id`,`file_name`),
  UNIQUE KEY `uq_url_file` (`url_id`,`file_name`),
  KEY `idx_files_status` (`status`),
  CONSTRAINT `fk_files_url` FOREIGN KEY (`url_id`) REFERENCES `urls` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records of files
-- ----------------------------
BEGIN;
INSERT INTO `files` (`id`, `url_id`, `file_name`, `expected_size_bytes`, `actual_size_bytes`, `downloaded_path`, `status`, `created_at`, `updated_at`) VALUES (73, 1, 'grant_pdf_20230124_r1.tar', 11243233280, NULL, NULL, 'failed', '2026-09-21 07:18:01', '2026-09-21 07:24:39');
INSERT INTO `files` (`id`, `url_id`, `file_name`, `expected_size_bytes`, `actual_size_bytes`, `downloaded_path`, `status`, `created_at`, `updated_at`) VALUES (74, 1, 'grant_pdf_20230131.tar', 13608386560, NULL, NULL, 'failed', '2026-09-21 07:18:01', '2026-09-21 07:24:54');
INSERT INTO `files` (`id`, `url_id`, `file_name`, `expected_size_bytes`, `actual_size_bytes`, `downloaded_path`, `status`, `created_at`, `updated_at`) VALUES (75, 1, 'grant_pdf_20230124.tar', 11208222720, NULL, NULL, 'failed', '2026-09-21 07:18:01', '2026-09-22 11:25:15');
INSERT INTO `files` (`id`, `url_id`, `file_name`, `expected_size_bytes`, `actual_size_bytes`, `downloaded_path`, `status`, `created_at`, `updated_at`) VALUES (76, 1, 'grant_pdf_20230117.tar', 10102138880, NULL, NULL, 'failed', '2026-09-21 07:18:01', '2026-09-22 11:25:39');
INSERT INTO `files` (`id`, `url_id`, `file_name`, `expected_size_bytes`, `actual_size_bytes`, `downloaded_path`, `status`, `created_at`, `updated_at`) VALUES (77, 1, 'grant_pdf_20230110.tar', 13067632640, NULL, NULL, 'failed', '2026-09-21 07:18:01', '2026-09-24 07:50:56');
INSERT INTO `files` (`id`, `url_id`, `file_name`, `expected_size_bytes`, `actual_size_bytes`, `downloaded_path`, `status`, `created_at`, `updated_at`) VALUES (78, 1, 'grant_pdf_20230103.tar', 13243637760, NULL, NULL, 'failed', '2026-09-21 07:18:01', '2026-10-01 13:22:51');
COMMIT;

-- ----------------------------
-- Table structure for url_event_logs
-- ----------------------------
DROP TABLE IF EXISTS `url_event_logs`;
CREATE TABLE `url_event_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url_id` int(10) unsigned DEFAULT NULL,
  `file_id` int(10) unsigned DEFAULT NULL,
  `level` enum('info','warning','error') NOT NULL DEFAULT 'info',
  `step` varchar(128) NOT NULL,
  `message` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_logs_file` (`file_id`),
  KEY `idx_logs_url_created` (`url_id`,`created_at`),
  CONSTRAINT `fk_logs_file` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_logs_url` FOREIGN KEY (`url_id`) REFERENCES `urls` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=173 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records of url_event_logs
-- ----------------------------
BEGIN;
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (53, NULL, NULL, 'info', 'LOGIN_STARTED', 'تلاش برای لاگین با اکانت ingen.nice@gmail.com', '2026-09-21 07:17:24');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (54, NULL, NULL, 'info', 'LOGIN_STEP_IDENTIFIER_SUBMITTED', 'ایمیل وارد و ارسال شد', '2026-09-21 07:17:32');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (55, NULL, NULL, 'info', 'LOGIN_STEP_PASSWORD_SUBMITTED', 'پسورد وارد و ارسال شد', '2026-09-21 07:17:33');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (56, NULL, NULL, 'info', 'LOGIN_STEP_2FA_GENERATING', 'در حال تولید خودکار کد TOTP', '2026-09-21 07:17:33');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (57, NULL, NULL, 'info', 'LOGIN_STEP_2FA_SUBMITTED', 'کد 2FA به‌صورت خودکار تولید و ارسال شد', '2026-09-21 07:17:33');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (58, NULL, NULL, 'info', 'LOGIN_REDIRECT_COMPLETED', 'ریدایرکت بعد از لاگین کامل شد. url نهایی: https://data.uspto.gov/home', '2026-09-21 07:17:38');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (59, NULL, NULL, 'info', 'LOGIN_SUCCESS', 'لاگین با ingen.nice@gmail.com موفق بود', '2026-09-21 07:17:38');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (60, 1, NULL, 'info', 'PAGE_OPENING', 'در حال باز کردن https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-01-01&fileDataToDate=2023-01-31', '2026-09-21 07:17:38');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (61, 1, NULL, 'info', 'PAGE_OPENED', 'صفحه با موفقیت باز شد', '2026-09-21 07:17:43');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (62, 1, NULL, 'info', 'PAGE_OPENING', 'در حال باز کردن https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-01-01&fileDataToDate=2023-01-31', '2026-09-21 07:17:49');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (63, 1, NULL, 'info', 'PAGE_OPENED', 'صفحه با موفقیت باز شد', '2026-09-21 07:17:53');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (64, 1, NULL, 'info', 'FILES_LISTED', 'تعداد 6 فایل مطابق با فیلتر یافت شد (از مجموع 1 صفحه)', '2026-09-21 07:18:01');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (65, 1, NULL, 'info', 'DOWNLOAD_QUEUE_STARTED', 'شروع دانلود ترتیبی 6 فایل (یکی‌یکی)', '2026-09-21 07:18:01');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (66, 1, 73, 'info', 'DOWNLOAD_REQUEST', 'درخواست دانلود فایل: grant_pdf_20230124_r1.tar', '2026-09-21 07:18:01');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (67, 1, 73, 'info', 'CAPTCHA_DIALOG_DETECTED', 'دیالوگ کپچا نمایش داده شد', '2026-09-21 07:18:01');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (68, 1, 73, 'info', 'CAPTCHA_OCR_ANSWER', 'OCR خواند: 2+8 = 10 (اطمینان 70%)', '2026-09-21 07:18:02');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (69, 1, 73, 'info', 'CAPTCHA_SOLVED', 'کپچا حل شد (منبع: ocr)', '2026-09-21 07:18:04');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (70, 1, 73, 'info', 'DOWNLOAD_STARTED', 'دانلود شروع شد: grant_pdf_20230124_r1.tar', '2026-09-21 07:18:06');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (71, 1, 73, 'info', 'DOWNLOAD_PROGRESS', 'grant_pdf_20230124_r1.tar: 0% (4.7 MB)', '2026-09-21 07:18:09');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (72, 1, NULL, 'info', 'KEEP_ALIVE_PING', 'keep-alive ارسال شد (status 200)', '2026-09-21 07:21:39');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (73, 1, 73, 'error', 'DOWNLOAD_ERROR', 'خطا در دانلود grant_pdf_20230124_r1.tar: download.path: canceled', '2026-09-21 07:24:39');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (74, 1, 74, 'info', 'DOWNLOAD_REQUEST', 'درخواست دانلود فایل: grant_pdf_20230131.tar', '2026-09-21 07:24:44');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (75, 1, 74, 'info', 'CAPTCHA_DIALOG_DETECTED', 'دیالوگ کپچا نمایش داده شد', '2026-09-21 07:24:44');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (76, 1, 74, 'info', 'CAPTCHA_OCR_ANSWER', 'OCR خواند: 1+8 = 9 (اطمینان 193%)', '2026-09-21 07:24:45');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (77, 1, 74, 'info', 'CAPTCHA_SOLVED', 'کپچا حل شد (منبع: ocr)', '2026-09-21 07:24:47');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (78, 1, 74, 'info', 'DOWNLOAD_STARTED', 'دانلود شروع شد: grant_pdf_20230131.tar', '2026-09-21 07:24:50');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (79, 1, 74, 'info', 'DOWNLOAD_PROGRESS', 'grant_pdf_20230131.tar: 0% (4.3 MB)', '2026-09-21 07:24:53');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (80, 1, 74, 'error', 'DOWNLOAD_ERROR', 'خطا در دانلود grant_pdf_20230131.tar: download.path: canceled', '2026-09-21 07:24:54');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (81, NULL, NULL, 'warning', 'RECOVERED_INTERRUPTED_STATE', 'بازیابی بعد از توقف ناگهانی: 1 job به paused و 0 فایل به registered برگشت', '2026-09-21 13:09:10');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (82, NULL, NULL, 'info', 'LOGIN_STARTED', 'تلاش برای لاگین با اکانت ingen.nice@gmail.com', '2026-09-21 13:09:17');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (83, NULL, NULL, 'error', 'LOGIN_ERROR', 'خطا در فرآیند لاگین: locator.waitFor: Target page, context or browser has been closed\nCall log:\n[2m  - waiting for locator(\'input[name=\"identifier\"]\') to be visible[22m\n', '2026-09-21 13:09:18');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (84, NULL, NULL, 'info', 'LOGIN_STARTED', 'تلاش برای لاگین با اکانت ingen.nice@gmail.com', '2026-09-22 11:24:03');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (85, NULL, NULL, 'info', 'LOGIN_STEP_IDENTIFIER_SUBMITTED', 'ایمیل وارد و ارسال شد', '2026-09-22 11:24:15');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (86, NULL, NULL, 'info', 'LOGIN_STEP_PASSWORD_SUBMITTED', 'پسورد وارد و ارسال شد', '2026-09-22 11:24:15');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (87, NULL, NULL, 'info', 'LOGIN_STEP_2FA_GENERATING', 'در حال تولید خودکار کد TOTP', '2026-09-22 11:24:16');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (88, NULL, NULL, 'info', 'LOGIN_STEP_2FA_SUBMITTED', 'کد 2FA به‌صورت خودکار تولید و ارسال شد', '2026-09-22 11:24:16');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (89, NULL, NULL, 'info', 'LOGIN_REDIRECT_COMPLETED', 'ریدایرکت بعد از لاگین کامل شد. url نهایی: https://data.uspto.gov/home', '2026-09-22 11:24:26');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (90, NULL, NULL, 'info', 'LOGIN_SUCCESS', 'لاگین با ingen.nice@gmail.com موفق بود', '2026-09-22 11:24:26');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (91, 1, NULL, 'info', 'PAGE_OPENING', 'در حال باز کردن https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-01-01&fileDataToDate=2023-01-31', '2026-09-22 11:24:26');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (92, 1, NULL, 'info', 'PAGE_OPENED', 'صفحه با موفقیت باز شد', '2026-09-22 11:24:34');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (93, 1, NULL, 'info', 'PAGE_OPENING', 'در حال باز کردن https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-01-01&fileDataToDate=2023-01-31', '2026-09-22 11:24:40');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (94, 1, NULL, 'info', 'PAGE_OPENED', 'صفحه با موفقیت باز شد', '2026-09-22 11:24:45');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (95, 1, NULL, 'info', 'FILES_LISTED', 'تعداد 6 فایل مطابق با فیلتر یافت شد (از مجموع 1 صفحه)', '2026-09-22 11:24:53');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (96, 1, NULL, 'info', 'DOWNLOAD_QUEUE_STARTED', 'شروع دانلود ترتیبی 4 فایل (یکی‌یکی)', '2026-09-22 11:24:53');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (97, 1, 75, 'info', 'DOWNLOAD_REQUEST', 'درخواست دانلود فایل: grant_pdf_20230124.tar', '2026-09-22 11:24:53');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (98, 1, 75, 'info', 'CAPTCHA_DIALOG_DETECTED', 'دیالوگ کپچا نمایش داده شد', '2026-09-22 11:24:53');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (99, 1, 75, 'info', 'CAPTCHA_OCR_ANSWER', 'OCR خواند: 6+5 = 11 (اطمینان 136%)', '2026-09-22 11:24:54');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (100, 1, 75, 'info', 'CAPTCHA_SOLVED', 'کپچا حل شد (منبع: ocr)', '2026-09-22 11:24:56');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (101, 1, 75, 'info', 'DOWNLOAD_STARTED', 'دانلود شروع شد: grant_pdf_20230124.tar', '2026-09-22 11:24:58');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (102, 1, 75, 'info', 'DOWNLOAD_PROGRESS', 'grant_pdf_20230124.tar: 0% (9.7 MB)', '2026-09-22 11:25:01');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (103, 1, 75, 'error', 'DOWNLOAD_ERROR', 'خطا در دانلود grant_pdf_20230124.tar: download.path: canceled', '2026-09-22 11:25:15');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (104, 1, 76, 'info', 'DOWNLOAD_REQUEST', 'درخواست دانلود فایل: grant_pdf_20230117.tar', '2026-09-22 11:25:20');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (105, 1, 76, 'info', 'DOWNLOAD_STARTED', 'دانلود شروع شد: grant_pdf_20230117.tar', '2026-09-22 11:25:34');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (106, 1, 76, 'info', 'DOWNLOAD_PROGRESS', 'grant_pdf_20230117.tar: 0% (3.2 MB)', '2026-09-22 11:25:37');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (107, 1, 76, 'error', 'DOWNLOAD_ERROR', 'خطا در دانلود grant_pdf_20230117.tar: download.path: canceled', '2026-09-22 11:25:39');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (108, 1, 77, 'info', 'DOWNLOAD_REQUEST', 'درخواست دانلود فایل: grant_pdf_20230110.tar', '2026-09-22 11:25:44');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (109, 1, NULL, 'error', 'JOB_ERROR', 'پردازش URL متوقف شد: page.bringToFront: Target page, context or browser has been closed', '2026-09-22 11:25:44');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (110, NULL, NULL, 'warning', 'RECOVERED_INTERRUPTED_STATE', 'بازیابی بعد از توقف ناگهانی: 0 job به paused و 1 فایل به registered برگشت', '2026-09-22 12:50:02');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (111, NULL, NULL, 'info', 'LOGIN_STARTED', 'تلاش برای لاگین با اکانت ingen.nice@gmail.com', '2026-09-24 07:48:11');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (112, NULL, NULL, 'info', 'LOGIN_STEP_IDENTIFIER_SUBMITTED', 'ایمیل وارد و ارسال شد', '2026-09-24 07:48:23');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (113, NULL, NULL, 'info', 'LOGIN_STEP_PASSWORD_SUBMITTED', 'پسورد وارد و ارسال شد', '2026-09-24 07:48:23');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (114, NULL, NULL, 'info', 'LOGIN_STEP_2FA_GENERATING', 'در حال تولید خودکار کد TOTP', '2026-09-24 07:48:23');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (115, NULL, NULL, 'info', 'LOGIN_STEP_2FA_SUBMITTED', 'کد 2FA به‌صورت خودکار تولید و ارسال شد', '2026-09-24 07:48:24');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (116, NULL, NULL, 'info', 'LOGIN_REDIRECT_COMPLETED', 'ریدایرکت بعد از لاگین کامل شد. url نهایی: https://data.uspto.gov/home', '2026-09-24 07:48:29');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (117, NULL, NULL, 'info', 'LOGIN_SUCCESS', 'لاگین با ingen.nice@gmail.com موفق بود', '2026-09-24 07:48:29');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (118, 1, NULL, 'info', 'PAGE_OPENING', 'در حال باز کردن https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-01-01&fileDataToDate=2023-01-31', '2026-09-24 07:48:29');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (119, 1, NULL, 'info', 'PAGE_OPENED', 'صفحه با موفقیت باز شد', '2026-09-24 07:48:39');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (120, 1, NULL, 'info', 'PAGE_OPENING', 'در حال باز کردن https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-01-01&fileDataToDate=2023-01-31', '2026-09-24 07:48:45');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (121, 1, NULL, 'info', 'PAGE_OPENED', 'صفحه با موفقیت باز شد', '2026-09-24 07:48:49');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (122, 1, NULL, 'info', 'FILES_LISTED', 'تعداد 6 فایل مطابق با فیلتر یافت شد (از مجموع 1 صفحه)', '2026-09-24 07:48:57');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (123, 1, NULL, 'info', 'DOWNLOAD_QUEUE_STARTED', 'شروع دانلود ترتیبی 2 فایل (یکی‌یکی)', '2026-09-24 07:48:57');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (124, 1, 77, 'info', 'DOWNLOAD_REQUEST', 'درخواست دانلود فایل: grant_pdf_20230110.tar', '2026-09-24 07:48:57');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (125, 1, 77, 'info', 'CAPTCHA_DIALOG_DETECTED', 'دیالوگ کپچا نمایش داده شد', '2026-09-24 07:48:57');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (126, 1, 77, 'info', 'CAPTCHA_OCR_UNSURE', 'OCR نتوانست هیچ عبارتی بخواند', '2026-09-24 07:48:59');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (127, 1, 77, 'error', 'BROWSER_DIED', 'مرورگر وسط دانلود grant_pdf_20230110.tar مرد؛ فایل برای تلاش مجدد آزاد شد', '2026-09-24 07:49:39');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (128, NULL, NULL, 'warning', 'RECOVERED_INTERRUPTED_STATE', 'بازیابی بعد از توقف ناگهانی: 1 job به paused و 0 فایل به registered برگشت', '2026-09-24 07:49:50');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (129, NULL, NULL, 'info', 'LOGIN_STARTED', 'تلاش برای لاگین با اکانت ingen.nice@gmail.com', '2026-09-24 07:50:00');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (130, NULL, NULL, 'info', 'LOGIN_STEP_IDENTIFIER_SUBMITTED', 'ایمیل وارد و ارسال شد', '2026-09-24 07:50:13');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (131, NULL, NULL, 'info', 'LOGIN_STEP_PASSWORD_SUBMITTED', 'پسورد وارد و ارسال شد', '2026-09-24 07:50:13');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (132, NULL, NULL, 'info', 'LOGIN_STEP_2FA_GENERATING', 'در حال تولید خودکار کد TOTP', '2026-09-24 07:50:14');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (133, NULL, NULL, 'info', 'LOGIN_STEP_2FA_SUBMITTED', 'کد 2FA به‌صورت خودکار تولید و ارسال شد', '2026-09-24 07:50:14');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (134, NULL, NULL, 'info', 'LOGIN_REDIRECT_COMPLETED', 'ریدایرکت بعد از لاگین کامل شد. url نهایی: https://data.uspto.gov/home', '2026-09-24 07:50:22');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (135, NULL, NULL, 'info', 'LOGIN_SUCCESS', 'لاگین با ingen.nice@gmail.com موفق بود', '2026-09-24 07:50:22');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (136, 1, NULL, 'info', 'PAGE_OPENING', 'در حال باز کردن https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-01-01&fileDataToDate=2023-01-31', '2026-09-24 07:50:22');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (137, 1, NULL, 'info', 'PAGE_OPENED', 'صفحه با موفقیت باز شد', '2026-09-24 07:50:29');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (138, 1, NULL, 'info', 'PAGE_OPENING', 'در حال باز کردن https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-01-01&fileDataToDate=2023-01-31', '2026-09-24 07:50:36');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (139, 1, NULL, 'info', 'PAGE_OPENED', 'صفحه با موفقیت باز شد', '2026-09-24 07:50:39');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (140, 1, NULL, 'info', 'FILES_LISTED', 'تعداد 6 فایل مطابق با فیلتر یافت شد (از مجموع 1 صفحه)', '2026-09-24 07:50:47');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (141, 1, NULL, 'info', 'DOWNLOAD_QUEUE_STARTED', 'شروع دانلود ترتیبی 2 فایل (یکی‌یکی)', '2026-09-24 07:50:47');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (142, 1, 77, 'info', 'DOWNLOAD_REQUEST', 'درخواست دانلود فایل: grant_pdf_20230110.tar', '2026-09-24 07:50:47');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (143, 1, 77, 'info', 'CAPTCHA_DIALOG_DETECTED', 'دیالوگ کپچا نمایش داده شد', '2026-09-24 07:50:47');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (144, 1, 77, 'info', 'CAPTCHA_CACHE_HIT', 'تصویر مشابه در کش پیدا شد؛ جواب: 7', '2026-09-24 07:50:48');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (145, 1, 77, 'info', 'CAPTCHA_SOLVED', 'کپچا حل شد (منبع: cache)', '2026-09-24 07:50:50');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (146, 1, 77, 'info', 'DOWNLOAD_STARTED', 'دانلود شروع شد: grant_pdf_20230110.tar', '2026-09-24 07:50:52');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (147, 1, 77, 'info', 'DOWNLOAD_PROGRESS', 'grant_pdf_20230110.tar: 0% (14.4 MB)', '2026-09-24 07:50:55');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (148, 1, 77, 'error', 'DOWNLOAD_ERROR', 'خطا در دانلود grant_pdf_20230110.tar: download.path: canceled', '2026-09-24 07:50:56');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (149, 1, 78, 'info', 'DOWNLOAD_REQUEST', 'درخواست دانلود فایل: grant_pdf_20230103.tar', '2026-09-24 07:51:01');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (150, NULL, NULL, 'warning', 'RECOVERED_INTERRUPTED_STATE', 'بازیابی بعد از توقف ناگهانی: 1 job به paused و 1 فایل به registered برگشت', '2026-10-01 13:21:23');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (151, NULL, NULL, 'info', 'LOGIN_STARTED', 'تلاش برای لاگین با اکانت ingen.nice@gmail.com', '2026-10-01 13:21:33');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (152, NULL, NULL, 'info', 'LOGIN_STEP_IDENTIFIER_SUBMITTED', 'ایمیل وارد و ارسال شد', '2026-10-01 13:21:42');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (153, NULL, NULL, 'info', 'LOGIN_STEP_PASSWORD_SUBMITTED', 'پسورد وارد و ارسال شد', '2026-10-01 13:21:43');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (154, NULL, NULL, 'info', 'LOGIN_STEP_2FA_GENERATING', 'در حال تولید خودکار کد TOTP', '2026-10-01 13:21:44');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (155, NULL, NULL, 'info', 'LOGIN_STEP_2FA_SUBMITTED', 'کد 2FA به‌صورت خودکار تولید و ارسال شد', '2026-10-01 13:21:44');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (156, NULL, NULL, 'info', 'LOGIN_REDIRECT_COMPLETED', 'ریدایرکت بعد از لاگین کامل شد. url نهایی: https://data.uspto.gov/home', '2026-10-01 13:21:51');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (157, NULL, NULL, 'info', 'LOGIN_SUCCESS', 'لاگین با ingen.nice@gmail.com موفق بود', '2026-10-01 13:21:51');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (158, 1, NULL, 'info', 'PAGE_OPENING', 'در حال باز کردن https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-01-01&fileDataToDate=2023-01-31', '2026-10-01 13:21:51');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (159, 1, NULL, 'info', 'PAGE_OPENED', 'صفحه با موفقیت باز شد', '2026-10-01 13:22:02');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (160, 1, NULL, 'info', 'PAGE_OPENING', 'در حال باز کردن https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-01-01&fileDataToDate=2023-01-31', '2026-10-01 13:22:08');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (161, 1, NULL, 'info', 'PAGE_OPENED', 'صفحه با موفقیت باز شد', '2026-10-01 13:22:12');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (162, 1, NULL, 'info', 'FILES_LISTED', 'تعداد 6 فایل مطابق با فیلتر یافت شد (از مجموع 1 صفحه)', '2026-10-01 13:22:20');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (163, 1, NULL, 'info', 'DOWNLOAD_QUEUE_STARTED', 'شروع دانلود ترتیبی 1 فایل (یکی‌یکی)', '2026-10-01 13:22:20');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (164, 1, 78, 'info', 'DOWNLOAD_REQUEST', 'درخواست دانلود فایل: grant_pdf_20230103.tar', '2026-10-01 13:22:20');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (165, 1, 78, 'info', 'CAPTCHA_DIALOG_DETECTED', 'دیالوگ کپچا نمایش داده شد', '2026-10-01 13:22:20');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (166, 1, 78, 'info', 'CAPTCHA_OCR_ANSWER', 'OCR خواند: 3+2 = 5 (اطمینان 3%)', '2026-10-01 13:22:22');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (167, 1, 78, 'info', 'CAPTCHA_SOLVED', 'کپچا حل شد (منبع: cli)', '2026-10-01 13:22:40');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (168, 1, 78, 'info', 'DOWNLOAD_STARTED', 'دانلود شروع شد: grant_pdf_20230103.tar', '2026-10-01 13:22:41');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (169, 1, 78, 'info', 'DOWNLOAD_PROGRESS', 'grant_pdf_20230103.tar: 0% (4.1 MB)', '2026-10-01 13:22:44');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (170, 1, 78, 'error', 'DOWNLOAD_ERROR', 'خطا در دانلود grant_pdf_20230103.tar: download.path: canceled', '2026-10-01 13:22:51');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (171, 1, NULL, 'info', 'DOWNLOAD_QUEUE_FINISHED', 'صف دانلود این URL تمام شد', '2026-10-01 13:22:51');
INSERT INTO `url_event_logs` (`id`, `url_id`, `file_id`, `level`, `step`, `message`, `created_at`) VALUES (172, 2, NULL, 'info', 'PAGE_OPENING', 'در حال باز کردن https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-02-01&fileDataToDate=2023-02-28', '2026-10-01 13:22:51');
COMMIT;

-- ----------------------------
-- Table structure for urls
-- ----------------------------
DROP TABLE IF EXISTS `urls`;
CREATE TABLE `urls` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `db_type` varchar(64) NOT NULL,
  `date_from` date NOT NULL,
  `date_to` date NOT NULL,
  `url` text NOT NULL,
  `status` enum('draft','scanning','processing','paused','downloaded','failure','verified') NOT NULL DEFAULT 'draft',
  `extensions_to_download` varchar(255) NOT NULL,
  `exclude_pattern_regex` varchar(512) DEFAULT NULL,
  `files_found_count` int(10) unsigned NOT NULL DEFAULT 0,
  `downloaded_files_count` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `processing_started_at` datetime DEFAULT NULL,
  `download_finished_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_urls_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records of urls
-- ----------------------------
BEGIN;
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (1, 'ptgrmp2', '2023-01-01', '2023-01-31', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-01-01&fileDataToDate=2023-01-31', 'downloaded', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 6, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-10-01 13:22:51', '2026-10-01 13:22:51');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (2, 'ptgrmp2', '2023-02-01', '2023-02-28', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-02-01&fileDataToDate=2023-02-28', 'scanning', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 4, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-10-01 13:22:51');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (3, 'ptgrmp2', '2023-03-01', '2023-03-31', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-03-01&fileDataToDate=2023-03-31', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (4, 'ptgrmp2', '2023-04-01', '2023-04-30', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-04-01&fileDataToDate=2023-04-30', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (5, 'ptgrmp2', '2023-05-01', '2023-05-31', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-05-01&fileDataToDate=2023-05-31', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (6, 'ptgrmp2', '2023-06-01', '2023-06-30', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-06-01&fileDataToDate=2023-06-30', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (7, 'ptgrmp2', '2023-07-01', '2023-07-31', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-07-01&fileDataToDate=2023-07-31', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (8, 'ptgrmp2', '2023-08-01', '2023-08-31', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-08-01&fileDataToDate=2023-08-31', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (9, 'ptgrmp2', '2023-09-01', '2023-09-30', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-09-01&fileDataToDate=2023-09-30', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (10, 'ptgrmp2', '2023-10-01', '2023-10-31', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-10-01&fileDataToDate=2023-10-31', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (11, 'ptgrmp2', '2023-11-01', '2023-11-30', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-11-01&fileDataToDate=2023-11-30', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (12, 'ptgrmp2', '2023-12-01', '2023-12-31', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2023-12-01&fileDataToDate=2023-12-31', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (13, 'ptgrmp2', '2024-01-01', '2024-01-31', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2025-01-01&fileDataToDate=2025-01-31', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (14, 'ptgrmp2', '2024-02-01', '2024-02-28', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2025-02-01&fileDataToDate=2025-02-28', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (15, 'ptgrmp2', '2024-03-01', '2024-03-31', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2025-03-01&fileDataToDate=2025-03-31', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (16, 'ptgrmp2', '2024-04-01', '2024-04-30', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2025-04-01&fileDataToDate=2025-04-30', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (17, 'ptgrmp2', '2024-05-01', '2024-05-31', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2025-05-01&fileDataToDate=2025-05-31', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (18, 'ptgrmp2', '2024-06-01', '2024-06-30', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2025-06-01&fileDataToDate=2025-06-30', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (19, 'ptgrmp2', '2024-07-01', '2024-07-31', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2025-07-01&fileDataToDate=2025-07-31', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (20, 'ptgrmp2', '2024-08-01', '2024-08-31', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2025-08-01&fileDataToDate=2025-08-31', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (21, 'ptgrmp2', '2024-09-01', '2024-09-30', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2025-09-01&fileDataToDate=2025-09-30', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (22, 'ptgrmp2', '2024-10-01', '2024-10-31', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2025-10-01&fileDataToDate=2025-10-31', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (23, 'ptgrmp2', '2024-11-01', '2024-11-30', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2025-11-01&fileDataToDate=2025-11-30', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
INSERT INTO `urls` (`id`, `db_type`, `date_from`, `date_to`, `url`, `status`, `extensions_to_download`, `exclude_pattern_regex`, `files_found_count`, `downloaded_files_count`, `created_at`, `processing_started_at`, `download_finished_at`, `updated_at`) VALUES (24, 'ptgrmp2', '2024-12-01', '2024-12-31', 'https://data.uspto.gov/bulkdata/datasets/ptgrmp2?fileDataFromDate=2025-12-01&fileDataToDate=2025-12-31', 'draft', 'pdf,zip', 'maint_|M\\d+(?=\\.tar$)', 0, 0, '2026-09-18 07:41:14', '2026-09-18 09:34:20', '2026-09-18 21:34:27', '2026-09-19 07:51:48');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
