/*
 Navicat Premium Data Transfer

 Source Server         : local (docker)
 Source Server Type    : MySQL
 Source Server Version : 110206 (11.2.6-MariaDB-ubu2204)
 Source Host           : 127.0.0.1:3306
 Source Schema         : usptodb

 Target Server Type    : MySQL
 Target Server Version : 110206 (11.2.6-MariaDB-ubu2204)
 File Encoding         : 65001

 Date: 19/09/2026 08:10:19
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for accounts
-- ----------------------------
DROP TABLE IF EXISTS `accounts`;
CREATE TABLE `accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(191) NOT NULL,
  `password` varchar(512) NOT NULL,
  `priority` smallint(6) NOT NULL DEFAULT 100,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_used_at` datetime DEFAULT NULL,
  `success_login_count` int(10) unsigned NOT NULL DEFAULT 0,
  `failed_login_count` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `2fa_secret` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_accounts_username` (`username`),
  KEY `idx_accounts_priority_active` (`is_active`,`priority`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Table structure for files
-- ----------------------------
DROP TABLE IF EXISTS `files`;
CREATE TABLE `files` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `url_id` int(10) unsigned NOT NULL,
  `file_name` varchar(512) NOT NULL,
  `expected_size_bytes` bigint(20) unsigned DEFAULT NULL,
  `actual_size_bytes` bigint(20) unsigned DEFAULT NULL,
  `downloaded_path` varchar(1024) DEFAULT NULL,
  `status` enum('registered','downloading','downloaded','verified_healthy','size_mismatch','failed') NOT NULL DEFAULT 'registered',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_files_url_filename` (`url_id`,`file_name`),
  KEY `idx_files_status` (`status`),
  CONSTRAINT `fk_files_url` FOREIGN KEY (`url_id`) REFERENCES `urls` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Table structure for url_event_logs
-- ----------------------------
DROP TABLE IF EXISTS `url_event_logs`;
CREATE TABLE `url_event_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url_id` int(10) unsigned DEFAULT NULL,
  `file_id` int(10) unsigned DEFAULT NULL,
  `level` enum('info','warning','error') NOT NULL DEFAULT 'info',
  `step` varchar(128) NOT NULL,
  `message` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fk_logs_file` (`file_id`),
  KEY `idx_logs_url_created` (`url_id`,`created_at`),
  CONSTRAINT `fk_logs_file` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_logs_url` FOREIGN KEY (`url_id`) REFERENCES `urls` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36430 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Table structure for urls
-- ----------------------------
DROP TABLE IF EXISTS `urls`;
CREATE TABLE `urls` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `db_type` varchar(64) NOT NULL,
  `date_from` date NOT NULL,
  `date_to` date NOT NULL,
  `url` text NOT NULL,
  `status` enum('draft','scanning','processing','downloaded','verified','failure') NOT NULL DEFAULT 'draft',
  `extensions_to_download` varchar(255) NOT NULL,
  `exclude_pattern_regex` varchar(512) DEFAULT NULL,
  `files_found_count` int(10) unsigned NOT NULL DEFAULT 0,
  `downloaded_files_count` int(10) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `processing_started_at` datetime DEFAULT NULL,
  `download_finished_at` datetime DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_urls_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

SET FOREIGN_KEY_CHECKS = 1;
