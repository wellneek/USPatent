/**
 * Runner: برنامه را با `pnpm start` اجرا می‌کند و اگر کرش کرد دوباره بالا می‌آورد.
 *
 * اجرا (داخل همان ترمینالِ session گرافیکی):
 *   pnpm run runner
 *
 * قواعد:
 *  - قبل از هر اجرا: اگر ساعت در بازه‌ی STOP_HOURS بود، منتظر می‌ماند
 *  - قبل از هر اجرا: پوشه‌ی پروفایل مرورگر (.browser-profile) پاک می‌شود
 *  - exit code 0   → اگر در بازه‌ی توقف هستیم (توقف نرمِ ساعتی) منتظر می‌ماند و دوباره اجرا می‌کند؛
 *                    وگرنه پایان عادی و خروج runner
 *  - exit code 130 → خروج فوری کاربر؛ restart نمی‌شود
 *  - هر چیز دیگر (خطا / kill شدن) → restart با backoff
 *  - Ctrl+C / SIGTERM روی runner → توقف نرم؛ بعد از خروج child دیگر restart نمی‌شود
 */
import "dotenv/config"; // باید اول از همه باشد تا STOP_HOURS خوانده شود
import { spawn, ChildProcess } from "child_process";
import fs from "fs/promises";
import path from "path";
import { config } from "./config";
import { StopController, parseStopHours } from "./utils/StopController";

const COMMAND = "pnpm";
const ARGS = ["start"];

const BASE_DELAY_MS = 5_000;        // اولین تأخیر قبل از restart
const MAX_DELAY_MS = 5 * 60_000;    // سقف backoff
const HEALTHY_RUN_MS = 10 * 60_000; // اگر این‌قدر زنده ماند، شمارنده‌ی شکست ریست می‌شود
const WAIT_LOG_INTERVAL_MS = 60_000;

let child: ChildProcess | null = null;
let stopRequested = false;
let signalCount = 0;

function ts(): string {
    return new Date().toISOString().replace("T", " ").slice(0, 19);
}
function log(msg: string): void {
    console.log(`[runner ${ts()}] ${msg}`);
}

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

/** خواب تکه‌ای تا با سیگنال سریع بیدار شویم */
async function interruptibleSleep(ms: number): Promise<void> {
    const deadline = Date.now() + ms;
    while (Date.now() < deadline && !stopRequested) {
        await sleep(Math.min(500, deadline - Date.now()));
    }
}

// اگر STOP_HOURS نامعتبر باشد همین‌جا خطا می‌دهد
// (این کنترلر فقط برای محاسبه‌ی بازه استفاده می‌شود؛ signal handler نصب نمی‌کنیم)
const stopWindowController = new StopController(parseStopHours(config.stopHours));

/**
 * نکته‌ی مهم: با Ctrl+C ترمینال، SIGINT به کل process group (شامل child) می‌رسد.
 * اگر ما هم دوباره forward کنیم، StopController برنامه آن را «سیگنال دوم» می‌داند و
 * فوری خارج می‌شود. پس SIGINT را forward نمی‌کنیم، ولی SIGTERM (مثلاً از pkill
 * روی خودِ runner) را یک‌بار forward می‌کنیم. سیگنال دوم به runner → kill اجباری child.
 */
function onSignal(signal: NodeJS.Signals): void {
    signalCount++;
    stopRequested = true;

    if (signalCount === 1) {
        log(`${signal} دریافت شد؛ منتظر توقف نرم برنامه می‌مانم (restart غیرفعال شد).`);
        if (signal === "SIGTERM" && child?.pid) {
            child.kill("SIGTERM");
        }
        return;
    }

    log(`${signal} دوباره دریافت شد؛ kill اجباری.`);
    if (child?.pid) child.kill("SIGKILL");
    process.exit(130);
}

process.on("SIGINT", onSignal);
process.on("SIGTERM", onSignal);

/**
 * اگر الان در بازه‌ی STOP_HOURS هستیم، تا پایان بازه صبر می‌کند.
 * خروجی: true یعنی می‌توان اجرا کرد، false یعنی توقف درخواست شده و باید خارج شد.
 */
async function waitUntilRunWindow(): Promise<boolean> {
    let lastLogAt = 0;
    let announced = false;

    while (!stopRequested) {
        const minutesLeft = stopWindowController.minutesUntilRunnable();
        if (minutesLeft === null) {
            if (announced) log("✅ به بازه‌ی مجاز اجرا رسیدیم.");
            return true;
        }

        if (Date.now() - lastLogAt >= WAIT_LOG_INTERVAL_MS) {
            log(
                `⏸️ منتظر زمان اجرای برنامه ... (STOP_HOURS=${config.stopHours}؛ ` +
                `حدود ${minutesLeft} دقیقه تا پایان بازه‌ی توقف)`
            );
            lastLogAt = Date.now();
            announced = true;
        }
        await sleep(1000);
    }
    return false;
}

/** پوشه‌ی پروفایل مرورگر را پاک می‌کند (تاریخچه/کش/کوکی‌ها؛ برنامه دوباره لاگین می‌کند) */
async function cleanBrowserProfile(): Promise<void> {
    const dir = config.browserProfileDir;

    // محافظ: هرگز ریشه، home یا خودِ پوشه‌ی پروژه را پاک نکن
    const root = path.parse(dir).root;
    if (dir === root || dir === process.env.HOME || dir === process.cwd()) {
        throw new Error(`مسیر پروفایل مرورگر خطرناک است و پاک نمی‌شود: ${dir}`);
    }

    try {
        await fs.rm(dir, { recursive: true, force: true, maxRetries: 5, retryDelay: 500 });
        log(`🧹 پروفایل مرورگر پاک شد: ${dir}`);
    } catch (err) {
        // اگر پاک نشد (مثلاً Chromium یتیم هنوز باز است) اجرا را متوقف نمی‌کنیم
        log(`⚠️ پاک کردن پروفایل ممکن نشد (${(err as Error).message}); ادامه می‌دهم.`);
    }
}

function runOnce(): Promise<{ code: number | null; signal: NodeJS.Signals | null; durationMs: number }> {
    return new Promise((resolve) => {
        const startedAt = Date.now();

        child = spawn(COMMAND, ARGS, {
            stdio: "inherit", // ترمینال، DISPLAY و stdin (برای کپچای دستی) همان‌طور که هست
            env: process.env,
            cwd: process.cwd(),
        });

        child.on("error", (err) => {
            log(`اجرای child ممکن نشد: ${err.message}`);
            child = null;
            resolve({ code: 1, signal: null, durationMs: Date.now() - startedAt });
        });

        child.on("exit", (code, signal) => {
            child = null;
            resolve({ code, signal, durationMs: Date.now() - startedAt });
        });
    });
}

async function main(): Promise<void> {
    let consecutiveFailures = 0;
    let runNumber = 0;

    while (!stopRequested) {
        // ۱) اگر در بازه‌ی توقف هستیم صبر کن
        if (!(await waitUntilRunWindow())) break;

        // ۲) پروفایل مرورگر را پاک کن
        await cleanBrowserProfile();

        // ۳) اجرا
        runNumber++;
        log(`▶️ اجرای شماره ${runNumber}: ${COMMAND} ${ARGS.join(" ")}`);

        const { code, signal, durationMs } = await runOnce();
        const durationSec = Math.round(durationMs / 1000);

        if (stopRequested) {
            log(`برنامه بعد از ${durationSec}s متوقف شد (code=${code}, signal=${signal}). خروج.`);
            return;
        }
        if (code === 130) {
            log("خروج فوری توسط کاربر تشخیص داده شد؛ restart نمی‌شود.");
            return;
        }
        if (code === 0) {
            // برنامه در «مرز امن» به‌خاطر رسیدن به STOP_HOURS خارج شده؟ پس منتظر می‌مانیم و دوباره اجرا می‌کنیم
            if (stopWindowController.minutesUntilRunnable() !== null) {
                log(`برنامه بعد از ${durationSec}s به‌خاطر بازه‌ی توقف خارج شد؛ بعد از پایان بازه دوباره اجرا می‌شود.`);
                consecutiveFailures = 0;
                continue; // بالای حلقه منتظر می‌ماند
            }
            log(`برنامه بعد از ${durationSec}s با موفقیت تمام شد. خروج.`);
            return;
        }

        // کرش: محاسبه‌ی backoff
        consecutiveFailures = durationMs >= HEALTHY_RUN_MS ? 1 : consecutiveFailures + 1;
        const delay = Math.min(BASE_DELAY_MS * 2 ** (consecutiveFailures - 1), MAX_DELAY_MS);

        log(
            `💥 برنامه بعد از ${durationSec}s کرش کرد (code=${code}, signal=${signal}). ` +
            `restart بعد از ${Math.round(delay / 1000)} ثانیه (شکست پیاپی: ${consecutiveFailures})`
        );
        await interruptibleSleep(delay);
    }
    log("توقف درخواست شد؛ خروج.");
}

main().then(() => process.exit(0));
