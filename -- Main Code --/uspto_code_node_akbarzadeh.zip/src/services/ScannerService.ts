import { Page } from "playwright";
import { UrlJob, ScannedFileCandidate } from "../types";
import { CaptchaService } from "./CaptchaService";
import { LogRepository } from "../db/LogRepository";
import { waitForElementReady, isElementVisibleSoon } from "../utils/waitForElement";

const TABLE_ROW_SELECTOR = "table.p-datatable-table tbody tr";
const NEXT_PAGE_BUTTON_SELECTOR = ".p-paginator-next:not(.p-disabled)";

export class ScannerService {
  constructor(
    private captchaService: CaptchaService,
    private logRepo: LogRepository
  ) { }

  /**
   * صفحه‌ی url job را باز می‌کند، لیست فایل‌ها را (با پیمایش صفحه‌بندی در صورت وجود)
   * می‌خواند و بر اساس extensionsToDownload و excludePatternRegex فیلتر می‌کند.
   */
  async scan(page: Page, job: UrlJob): Promise<ScannedFileCandidate[]> {
    
    await this.openJobPage(page, job);
    const excludeRegex = job.excludePatternRegex ? new RegExp(job.excludePatternRegex) : null;

    
    await this.logRepo.log(job.id, "PAGE_OPENING", `در حال باز کردن ${job.url}`);
    await page.goto(job.url, { waitUntil: "networkidle" });
    await this.logRepo.log(job.id, "PAGE_OPENED", "صفحه با موفقیت باز شد");

    // تا امروز کپچایی در این صفحه (قبل از کلیک دانلود) دیده نشده، ولی برای احتیاط چک می‌کنیم
    await this.captchaService.handleIfPresent(page, job.id);

    await waitForElementReady(page, TABLE_ROW_SELECTOR, {
      description: "جدول لیست فایل‌ها",
      timeoutMs: 300000,
    });

    const allCandidates: ScannedFileCandidate[] = [];
    let pageIndex = 1;

    // پیمایش صفحه‌بندی PrimeNG (در صورت وجود بیش از یک صفحه نتیجه)
    // eslint-disable-next-line no-constant-condition
    while (true) {
      const rowCandidates = await this.extractRowsFromCurrentPage(page, job, excludeRegex);
      allCandidates.push(...rowCandidates);

      const hasNextPage = await isElementVisibleSoon(page, NEXT_PAGE_BUTTON_SELECTOR, 1500);
      if (!hasNextPage) break;

      pageIndex++;
      await this.logRepo.log(job.id, "SCAN_NEXT_PAGE", `رفتن به صفحه‌ی ${pageIndex} جدول فایل‌ها`);
      await page.locator(NEXT_PAGE_BUTTON_SELECTOR).click();
      await page.waitForLoadState("networkidle");
      // کمی صبر برای رندر مجدد جدول (PrimeNG async است)
      await page.waitForTimeout(500);
    }

    await this.logRepo.log(
      job.id,
      "FILES_LISTED",
      `تعداد ${allCandidates.length} فایل مطابق با فیلتر یافت شد (از مجموع ${pageIndex} صفحه)`
    );

    return allCandidates;
  }

  /** صفحه‌ی جاب را باز می‌کند و منتظر آماده شدن جدول می‌ماند (بدون اسکن) */
  async openJobPage(page: Page, job: UrlJob): Promise<void> {
    await this.logRepo.log(job.id, "PAGE_OPENING", `در حال باز کردن ${job.url}`);
    await page.goto(job.url, { waitUntil: "networkidle" });
    await this.logRepo.log(job.id, "PAGE_OPENED", "صفحه با موفقیت باز شد");

    await this.captchaService.handleIfPresent(page, job.id);

    await waitForElementReady(page, TABLE_ROW_SELECTOR, {
      description: "جدول لیست فایل‌ها",
      timeoutMs: 300000,
    });
  }

  private async extractRowsFromCurrentPage(
    page: Page,
    job: UrlJob,
    excludeRegex: RegExp | null
  ): Promise<ScannedFileCandidate[]> {
    const rows = await page.locator(TABLE_ROW_SELECTOR).all();
    const candidates: ScannedFileCandidate[] = [];

    for (const row of rows) {
      // ستون ۱: نام فایل داخل <a href="#">...</a>
      const fileName = (await row.locator("td").nth(0).locator("a").textContent())?.trim() ?? "";
      if (!fileName) continue;

      // ستون ۳: حجم فایل داخل <div class="number">11,243,233,280</div>
      const sizeText = (await row.locator("td").nth(2).locator(".number").textContent())?.trim() ?? "";
      const expectedSizeBytes = this.parseSizeWithCommas(sizeText);

      if (!this.fileMatchesExtensions(fileName, job.extensionsToDownload)) continue;
      if (excludeRegex && excludeRegex.test(fileName)) continue;

      candidates.push({
        fileName,
        expectedSizeBytes,
        downloadHref: null, // href واقعی "#" است؛ دانلود با کلیک روی <a> و هندل کردن کپچا/تب جدید انجام می‌شود
      });
    }

    return candidates;
  }

  /**
   * طبق توضیح کاربر: هم پسوند واقعی فایل چک می‌شود، هم اینکه پسوند به‌عنوان
   * یک token جدا با "_" (یا "." یا "-") داخل اسم فایل آمده باشد.
   * مثال: "grant_pdf_20230124_r1.tar" با extensionsToDownload=["pdf"] چون
   * توکن "pdf" در اسم فایل هست، match می‌شود؛ حتی با اینکه پسوند واقعی .tar است.
   */
  private fileMatchesExtensions(fileName: string, extensions: string[]): boolean {
    const lower = fileName.toLowerCase();
    const realExtension = lower.split(".").pop() ?? "";
    const normalizedExtensions = extensions.map((e) => e.toLowerCase().trim());

    if (normalizedExtensions.includes(realExtension)) return true;

    const tokens = lower.split(/[._-]/);
    return normalizedExtensions.some((ext) => tokens.includes(ext));
  }

  /** "11,243,233,280" -> 11243233280 */
  private parseSizeWithCommas(sizeText: string): number | null {
    const cleaned = sizeText.replace(/,/g, "").trim();
    if (!cleaned || Number.isNaN(Number(cleaned))) return null;
    return parseInt(cleaned, 10);
  }
}
