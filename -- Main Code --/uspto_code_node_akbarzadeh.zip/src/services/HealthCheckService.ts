import { FileRepository } from "../db/FileRepository";
import { LogRepository } from "../db/LogRepository";
import { FileRecord } from "../types";
import fs from "fs/promises";

const DEFAULT_TOLERANCE_BYTES = 200 * 1024; // 200 KB

export class HealthCheckService {
  constructor(
    private fileRepo: FileRepository,
    private logRepo: LogRepository,
    private toleranceBytes: number = DEFAULT_TOLERANCE_BYTES
  ) {}

  /**
   * فایل‌های "downloaded" یک url را بررسی می‌کند: اگر اختلاف حجم واقعی و
   * حجم مورد انتظار در بازه‌ی تلورانس بود -> verified_healthy
   * در غیر این صورت طبق نیاز وضعیت downloaded باقی می‌ماند.
   */
  async checkFile(file: FileRecord, urlId: number): Promise<void> {
    if (!file.downloadedPath) {
      await this.logRepo.log(
        urlId,
        "HEALTH_CHECK_FILE_MISSING",
        `مسیر فایل دانلودشده ثبت نشده است: ${file.fileName}`,
        "warning",
        file.id
      );
      return;
    }

    let actualSize: number;
    try {
      actualSize = (await fs.stat(file.downloadedPath)).size;
    } catch (error) {
      await this.logRepo.log(
        urlId,
        "HEALTH_CHECK_FILE_MISSING",
        `فایل در مسیر ثبت‌شده پیدا نشد: ${file.downloadedPath} (${(error as Error).message})`,
        "warning",
        file.id
      );
      return;
    }

    if (file.expectedSizeBytes == null) {
      await this.logRepo.log(
        urlId,
        "HEALTH_CHECK_SKIPPED",
        `حجم مورد انتظار نامشخص است برای ${file.fileName}`,
        "warning",
        file.id
      );
      return;
    }

    const diff = Math.abs(file.expectedSizeBytes - actualSize);

    if (diff <= this.toleranceBytes) {
      await this.fileRepo.updateStatus(file.id, "verified_healthy");
      await this.logRepo.log(
        urlId,
        "HEALTH_CHECK_OK",
        `فایل ${file.fileName} سالم است (اختلاف ${diff} بایت)`,
        "info",
        file.id
      );
    } else {
      // طبق نیاز، در اختلاف بیش از تلورانس وضعیت همان downloaded می‌ماند.
      await this.logRepo.log(
        urlId,
        "HEALTH_CHECK_MISMATCH",
        `اختلاف حجم زیاد است در ${file.fileName}: انتظار=${file.expectedSizeBytes} واقعی=${actualSize}`,
        "warning",
        file.id
      );
    }
  }
}
