import fs from "fs/promises";
import path from "path";

/** پسوندهای فایل موقت که مرورگر/Playwright حین دانلود می‌سازد */
const TEMP_EXTENSIONS = [".crdownload", ".part", ".partial", ".tmp", ".download"];

export interface ProgressSnapshot {
  /** نام فایلی که در حال رشد است (موقت یا GUID) */
  fileName: string;
  bytesDownloaded: number;
  /** درصد، فقط اگر حجم مورد انتظار را بدانیم */
  percent: number | null;
  /** بایت بر ثانیه، میانگین از آخرین poll */
  speedBytesPerSec: number;
  /** ثانیه تا پایان، فقط اگر حجم مورد انتظار و سرعت را بدانیم */
  etaSeconds: number | null;
  elapsedMs: number;
}

export interface TrackOptions {
  /** حجمی که از جدول سایت خوانده‌ایم - برای محاسبه درصد و ETA */
  expectedSizeBytes: number | null;
  /** هر چند میلی‌ثانیه پوشه را چک کنیم (پیش‌فرض ۵ ثانیه) */
  pollIntervalMs?: number;
  /**
   * اگر این مدت حجم فایل هیچ رشدی نکرد، دانلود را مرده در نظر می‌گیریم.
   * برای فایل‌های چندگیگی بدون resume این مهم‌ترین محافظ است؛ بدون آن
   * ممکن است ۶۰ دقیقه منتظر چیزی بمانیم که همان دقیقه‌ی اول مرده است.
   * پیش‌فرض: ۱۰ دقیقه
   */
  stallTimeoutMs?: number;
  /** سقف کل زمان یک دانلود */
  overallTimeoutMs: number;
  onProgress?: (snapshot: ProgressSnapshot) => void | Promise<void>;
}

export class DownloadStalledError extends Error {
  constructor(public readonly lastBytes: number, stallMs: number) {
    super(
      `دانلود متوقف شده است: طی ${Math.round(
        stallMs / 1000
      )} ثانیه هیچ رشدی در حجم فایل دیده نشد (آخرین حجم: ${lastBytes} بایت)`
    );
    this.name = "DownloadStalledError";
  }
}

/**
 * پوشه‌ی دانلود را با polling رصد می‌کند.
 *
 * چرا polling و نه fs.watch؟
 *  - fs.watch فقط می‌گوید «چیزی تغییر کرد» ولی حجم نمی‌دهد؛ ما دقیقا حجم را می‌خواهیم
 *  - روی فایلی که مدام append می‌شود، inotify سیل رویداد تولید می‌کند
 *  - readdir+stat هر چند ثانیه روی پوشه‌ای با چند فایل عملا رایگان است
 *  - و مهم‌تر: با polling می‌توان stall را تشخیص داد
 */
export class DownloadMonitor {
  constructor(private downloadDir: string) {}

  /**
   * منتظر می‌ماند تا یک دانلود کامل شود، و در این مدت پیشرفت را گزارش می‌دهد.
   *
   * `completionPromise` همان promise ای است که Playwright موقع تمام شدن دانلود
   * resolve می‌کند (مثلا download.path()). ما به آن تکیه می‌کنیم برای تشخیص
   * «پایان»، و از فایل‌سیستم فقط برای «پیشرفت» و «تشخیص مرگ» استفاده می‌کنیم.
   * این ترکیب از هر دو روش امن‌تر است: نه به حدس زدن از روی فایل موقت وابسته‌ایم،
   * نه کورکورانه منتظر یک promise می‌مانیم که شاید هرگز resolve نشود.
   */
  async trackUntilComplete<T>(
    completionPromise: Promise<T>,
    options: TrackOptions
  ): Promise<T> {
    const {
      expectedSizeBytes,
      pollIntervalMs = 5000,
      stallTimeoutMs = 10 * 60 * 1000,
      overallTimeoutMs,
      onProgress,
    } = options;

    const startedAt = Date.now();
    let settled = false;
    let lastBytes = 0;
    let lastGrowthAt = Date.now();
    let previousBytes = 0;
    let previousAt = Date.now();

    // وقتی دانلود تمام شد، حلقه‌ی رصد باید متوقف شود
    const wrapped = completionPromise.finally(() => {
      settled = true;
    });

    const monitorLoop = (async () => {
      while (!settled) {
        await sleep(pollIntervalMs);
        if (settled) break;

        const now = Date.now();

        if (now - startedAt > overallTimeoutMs) {
          throw new Error(
            `دانلود از سقف زمانی مجاز (${Math.round(
              overallTimeoutMs / 60000
            )} دقیقه) عبور کرد`
          );
        }

        const inProgress = await this.findLargestInProgressFile();
        if (!inProgress) continue;

        lastBytes = inProgress.sizeBytes;

        if (lastBytes > previousBytes) {
          lastGrowthAt = now;
        } else if (now - lastGrowthAt > stallTimeoutMs) {
          throw new DownloadStalledError(lastBytes, now - lastGrowthAt);
        }

        const deltaBytes = lastBytes - previousBytes;
        const deltaMs = now - previousAt;
        const speed = deltaMs > 0 ? (deltaBytes / deltaMs) * 1000 : 0;

        const percent =
          expectedSizeBytes && expectedSizeBytes > 0
            ? Math.min(100, (lastBytes / expectedSizeBytes) * 100)
            : null;

        const etaSeconds =
          expectedSizeBytes && speed > 0
            ? Math.max(0, (expectedSizeBytes - lastBytes) / speed)
            : null;

        if (onProgress) {
          await onProgress({
            fileName: inProgress.fileName,
            bytesDownloaded: lastBytes,
            percent,
            speedBytesPerSec: speed,
            etaSeconds,
            elapsedMs: now - startedAt,
          });
        }

        previousBytes = lastBytes;
        previousAt = now;
      }
    })();

    // هر کدام زودتر تمام شد: یا دانلود موفق، یا خطای stall/timeout از حلقه‌ی رصد
    return Promise.race([wrapped, monitorLoop.then(() => wrapped)]);
  }

  /**
   * بزرگ‌ترین فایلِ «در حال دانلود» را در پوشه پیدا می‌کند.
   *
   * دو حالت را پوشش می‌دهد:
   *  ۱) فایل موقت مرورگر با پسوندهایی مثل .crdownload
   *  ۲) فایل موقت Playwright که نام GUID بدون پسوند دارد
   *     (چون acceptDownloads=true است، معمولا این حالت رخ می‌دهد)
   *
   * بزرگ‌ترین را برمی‌گرداند چون در هر لحظه فقط یک دانلود فعال داریم و
   * فایل در حال رشد قاعدتا بزرگ‌ترین فایل ناتمام است.
   */
  private async findLargestInProgressFile(): Promise<{
    fileName: string;
    sizeBytes: number;
  } | null> {
    let entries: string[];
    try {
      entries = await fs.readdir(this.downloadDir);
    } catch {
      return null;
    }

    let best: { fileName: string; sizeBytes: number } | null = null;

    for (const entry of entries) {
      const looksTemporary =
        TEMP_EXTENSIONS.some((ext) => entry.toLowerCase().endsWith(ext)) ||
        !path.extname(entry); // فایل بدون پسوند = احتمالا فایل موقت GUID پلی‌رایت

      if (!looksTemporary) continue;

      try {
        const stat = await fs.stat(path.join(this.downloadDir, entry));
        if (!stat.isFile()) continue;
        if (!best || stat.size > best.sizeBytes) {
          best = { fileName: entry, sizeBytes: stat.size };
        }
      } catch {
        // فایل ممکن است بین readdir و stat حذف شده باشد (مثلا rename نهایی) - نادیده بگیر
      }
    }

    return best;
  }

  /**
   * بعد از اینکه دانلود تمام شد، مطمئن می‌شود فایل نهایی واقعا روی دیسک نشسته
   * و حجمش دیگر تغییر نمی‌کند (یعنی سیستم‌عامل flush را تمام کرده).
   */
  async waitForStableFile(
    filePath: string,
    stableForMs: number = 3000,
    timeoutMs: number = 60000
  ): Promise<number> {
    const deadline = Date.now() + timeoutMs;
    let lastSize = -1;
    let stableSince = 0;

    while (Date.now() < deadline) {
      let size: number;
      try {
        size = (await fs.stat(filePath)).size;
      } catch {
        await sleep(500);
        continue;
      }

      if (size === lastSize && size > 0) {
        if (stableSince === 0) stableSince = Date.now();
        if (Date.now() - stableSince >= stableForMs) return size;
      } else {
        lastSize = size;
        stableSince = 0;
      }

      await sleep(500);
    }

    throw new Error(`حجم فایل ${filePath} ظرف مهلت مقرر پایدار نشد`);
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/** کمکی برای نمایش خوانا در لاگ */
export function formatBytes(bytes: number): string {
  if (bytes >= 1024 ** 3) return `${(bytes / 1024 ** 3).toFixed(2)} GB`;
  if (bytes >= 1024 ** 2) return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
  if (bytes >= 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${bytes} B`;
}

export function formatDuration(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${s}s`;
  return `${s}s`;
}
