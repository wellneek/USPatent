import { Page } from "playwright";
import { Account } from "../types";
import { AccountRepository } from "../db/AccountRepository";
import { LogRepository } from "../db/LogRepository";
import { CaptchaService } from "./CaptchaService";
// import { askCli } from "../cli/prompt"; // fallback دستی 2FA در صورت نیاز آینده
import { UsptoPageAdapter } from "../site/UsptoPageAdapter";
import * as OTPAuth from "otpauth";


export class AuthService {
    constructor(
        private accountRepo: AccountRepository,
        private logRepo: LogRepository,
        private captchaService: CaptchaService,
        private site: UsptoPageAdapter,
        public readonly homeUrl: string = "https://data.uspto.gov/"
    ) {}

    /**
     * تشخیص لاگین بودن از روی هدر سایت.
     * وقتی کاربر لاگین نیست: <a class="user-link">Sign in</a>
     * وقتی کاربر لاگین است: <button class="... user-link">...</button> + یک
     * دکمه‌ی <button class="logout-button">Sign out</button> داخل dropdown.
     * چون logout-button فقط در حالت لاگین وجود دارد، بهترین indicator همین است.
     */
    async isLoggedIn(page: Page): Promise<boolean> {
        return this.site.isLoggedIn(page);
    }


        /**
     * از روی صفحه‌ی فعلی (بدون رفتن به home) بررسی می‌کند لاگین هستیم یا نه.
     * اگر نبودیم، لاگین می‌کند. خروجی true یعنی لاگین مجدد انجام شد
     * (پس caller باید دوباره به صفحه‌ی لیست برود).
     */
    async ensureLoggedIn(page: Page, urlId: number | null = null): Promise<boolean> {
        if (await this.site.isLoggedIn(page)) return false;

        await this.logRepo.log(
            urlId,
            "SESSION_LOST",
            "لاگین نیستیم (دکمه‌ی خروج در هدر پیدا نشد)؛ تلاش برای لاگین مجدد",
            "warning"
        );

        const account = await this.accountRepo.pickNextAvailableAccount();
        if (!account) throw new Error("هیچ اکانت فعالی برای لاگین پیدا نشد.");

        const ok = await this.login(page, account, urlId);
        if (!ok) throw new Error(`لاگین مجدد با اکانت ${account.username} ناموفق بود.`);

        await this.logRepo.log(urlId, "SESSION_RESTORED", "لاگین مجدد موفق بود");
        return true;
    }


    /**
     * فرآیند کامل لاگین:
     *  ۱) کلیک روی "Sign in" در هدر (ریدایرکت به auth.uspto.gov/Okta)
     *  ۲) وارد کردن ایمیل + تیک "Keep me signed in" (rememberMe)
     *  ۳) وارد کردن پسورد
     *  ۴) تولید کد TOTP از 2fa_secret و وارد کردن خودکار آن
     *  ۵) انتظار برای ریدایرکت خودکار: auth.uspto.gov -> data.uspto.gov/login/callback -> صفحه‌ی درخواستی اولیه
     */
    async login(page: Page, account: Account, urlIdForLog: number | null = null): Promise<boolean> {
        await this.logRepo.log(urlIdForLog, "LOGIN_STARTED", `تلاش برای لاگین با اکانت ${account.username}`);
        console.log(`🔐 در حال لاگین با اکانت: ${account.username} ...`);

        try {
            // مطمئن می‌شویم روی صفحه‌ی اصلی هستیم تا لینک "Sign in" در هدر موجود باشد
            if (!page.url().startsWith(this.homeUrl)) {
                await page.goto(this.homeUrl, { waitUntil: "networkidle" });
            }

            // ---------- کلیک روی "Sign in" ----------
            await page.locator("#global-header a.user-link", { hasText: "Sign in" }).click();
            await page.waitForLoadState("networkidle");
            await this.captchaService.handleIfPresent(page, urlIdForLog);

            // ---------- مرحله ۱: ایمیل + Remember me ----------
            await this.fillIdentifierStep(page, account);
            await this.logRepo.log(urlIdForLog, "LOGIN_STEP_IDENTIFIER_SUBMITTED", "ایمیل وارد و ارسال شد");
            await this.captchaService.handleIfPresent(page, urlIdForLog);

            // ---------- مرحله ۲: پسورد ----------
            await this.fillPasswordStep(page, account);
            await this.logRepo.log(urlIdForLog, "LOGIN_STEP_PASSWORD_SUBMITTED", "پسورد وارد و ارسال شد");
            await this.captchaService.handleIfPresent(page, urlIdForLog);

            // ---------- مرحله ۳: تولید خودکار کد TOTP ----------
            const needs2fa = await this.isOtpStepVisible(page);
            if (needs2fa) {
                console.log("📟 در حال تولید خودکار کد 2FA...");
                await this.logRepo.log(urlIdForLog, "LOGIN_STEP_2FA_GENERATING", "در حال تولید خودکار کد TOTP");

                // const code = await askCli("لطفاً کد 2FA (Authenticator) را وارد کنید: ");
                const code = this.generateTotpCode(account.twoFaSecret);
                await this.fillOtpStep(page, code);
                await this.logRepo.log(urlIdForLog, "LOGIN_STEP_2FA_SUBMITTED", "کد 2FA به‌صورت خودکار تولید و ارسال شد");
            }

            // ---------- مرحله ۴: انتظار برای ریدایرکت خودکار بعد از لاگین ----------
            // سایت به‌صورت خودکار از auth.uspto.gov به data.uspto.gov/login/callback
            // می‌رود و از آنجا به صفحه‌ای که قبل از لاگین درخواست شده بود (معمولا /home).
            // این می‌تواند چند ثانیه و چند hop طول بکشد؛ رگکس ساده روی /home گاهی
            // به خاطر تایمینگ رد می‌شود، پس این‌جا صبر می‌کنیم تا کامل از auth.uspto.gov
            // و از صفحه‌ی /login/callback خارج شویم.
            await this.waitForPostLoginRedirect(page, urlIdForLog);

            const success = await this.isLoggedIn(page);
            if (success) {
                await this.accountRepo.markLoginSuccess(account.id);
                await this.logRepo.log(urlIdForLog, "LOGIN_SUCCESS", `لاگین با ${account.username} موفق بود`);
            } else {
                await this.accountRepo.markLoginFailure(account.id);
                await this.logRepo.log(urlIdForLog, "LOGIN_FAILED", `لاگین با ${account.username} ناموفق بود`, "error");
            }
            return success;
        } catch (err) {
            await this.accountRepo.markLoginFailure(account.id);
            await this.logRepo.log(
                urlIdForLog,
                "LOGIN_ERROR",
                `خطا در فرآیند لاگین: ${(err as Error).message}`,
                "error"
            );
            return false;
        }
    }

    // ------------------------------------------------------------------
    // مراحل داخلی فرم Okta
    // ------------------------------------------------------------------

    private async fillIdentifierStep(page: Page, account: Account): Promise<void> {
        const identifierInput = page.locator('input[name="identifier"]');
        await identifierInput.waitFor({ state: "visible" });

        // ممکن است فیلد از قبل مقدار پیش‌فرض داشته باشد (طبق نمونه HTML)، پس اول پاک می‌کنیم
        await identifierInput.fill("");
        await identifierInput.fill(account.username);

        // چک‌باکس "Keep me signed in" (rememberMe) - طبق خواسته باید تیک بخورد.
        //
        // نکته مهم: input واقعی چک‌باکس با CSS مخفی/overlay شده و یک <label>
        // دقیقا رویش قرار گرفته. کلیک/check مستقیم روی input شکست می‌خورد چون
        // Playwright گزارش می‌دهد "label intercepts pointer events" - یعنی
        // کلیک واقعا به label می‌خورد نه به input. راه‌حل: مستقیم روی خودِ
        // label (با selector پایدار data-se-for-name، نه id داینامیک مثل input36) کلیک کن.
        try {
            const rememberMeInput = page.locator('input[name="rememberMe"]');
            await rememberMeInput.waitFor({ state: "attached", timeout: 15000 });

            const alreadyChecked = await rememberMeInput.isChecked().catch(() => false);
            if (!alreadyChecked) {
                const rememberMeLabel = page.locator(
                    '.custom-checkbox label[data-se-for-name="rememberMe"]'
                );
                await rememberMeLabel.waitFor({ state: "visible", timeout: 15000 });
                await rememberMeLabel.click();

                const nowChecked = await rememberMeInput.isChecked().catch(() => false);
                if (!nowChecked) {
                    console.warn(
                        "⚠️ بعد از کلیک روی label، چک‌باکس rememberMe هنوز تیک نخورده؛ ادامه می‌دهیم بدون آن."
                    );
                }
            }
        } catch (e) {
            console.error("چک‌باکس remember me پیدا نشد یا قابل تیک زدن نبود!", e);
        }

        const nextBtn = page.locator('input[type="submit"][value="Next"]');
        await nextBtn.waitFor({ state: "visible" });
        await nextBtn.click();
        await page.waitForLoadState("networkidle");
    }

    private async fillPasswordStep(page: Page, account: Account): Promise<void> {
        // مطمئن می‌شویم واقعا در مرحله‌ی پسورد هستیم (نه مثلا مستقیم رفته به OTP)
        await page
            .locator(".challenge-authenticator--okta_password")
            .waitFor({ state: "visible", timeout: 15000 });

        const plainPassword = this.decryptPassword(account.password);

        await page.locator('input[name="credentials.passcode"]').waitFor({ state: "visible" });
        await page.fill('input[name="credentials.passcode"]', plainPassword);
        await page.locator('input[type="submit"][value="Verify"]').waitFor({ state: "visible" });
        await page.locator('input[type="submit"][value="Verify"]').click();
        await page.waitForLoadState("networkidle");
    }

    private async isOtpStepVisible(page: Page): Promise<boolean> {
        const otpContainer = page.locator(".challenge-authenticator--custom_otp");
        try {
            await otpContainer.waitFor({ state: "visible", timeout: 10000 });
            return true;
        } catch {
            return false;
        }
    }

    private async fillOtpStep(page: Page, code: string): Promise<void> {
        await page.fill('.challenge-authenticator--custom_otp input[name="credentials.passcode"]', code);
        await page
            .locator('.challenge-authenticator--custom_otp input[type="submit"][value="Verify"]').waitFor()
        await page
            .locator('.challenge-authenticator--custom_otp input[type="submit"][value="Verify"]')
            .click();
        await page.waitForLoadState("networkidle");
    }

    /**
     * بعد از تایید آخرین مرحله (پسورد یا 2FA)، سایت خودش چند ریدایرکت پشت‌سرهم
     * انجام می‌دهد: از auth.uspto.gov خارج می‌شود، از data.uspto.gov/login/callback
     * عبور می‌کند و در نهایت به صفحه‌ای که قبل از لاگین درخواست شده بود می‌رسد.
     * این تابع صبر می‌کند تا این زنجیره کامل تمام شود، نه فقط یک navigation ساده.
     */
    private async waitForPostLoginRedirect(page: Page, urlIdForLog: number | null): Promise<void> {
        const timeoutMs = 45000;
        const pollIntervalMs = 500;
        const deadline = Date.now() + timeoutMs;

        // مرحله اول: خارج شدن کامل از دامنه auth.uspto.gov (یعنی okta کارش تمام شده)
        while (Date.now() < deadline) {
            if (!page.url().includes("auth.uspto.gov")) break;
            await page.waitForTimeout(pollIntervalMs);
        }

        // مرحله دوم: رد شدن از صفحه‌ی واسط login/callback
        while (Date.now() < deadline) {
            if (!page.url().includes("/login/callback")) break;
            await page.waitForTimeout(pollIntervalMs);
        }

        if (Date.now() >= deadline) {
            await this.logRepo.log(
                urlIdForLog,
                "LOGIN_REDIRECT_TIMEOUT",
                `بعد از ${timeoutMs / 1000} ثانیه هنوز روی صفحه واسط لاگین بودیم (url فعلی: ${page.url()})`,
                "warning"
            );
        }

        // منتظر می‌مانیم صفحه‌ی نهایی کامل لود شود
        await page.waitForLoadState("networkidle").catch(() => {});

        await this.logRepo.log(
            urlIdForLog,
            "LOGIN_REDIRECT_COMPLETED",
            `ریدایرکت بعد از لاگین کامل شد. url نهایی: ${page.url()}`
        );
    }

    /**
     * کد TOTP فعلی را از Google Authenticator Key URI ذخیره‌شده در دیتابیس
     * تولید می‌کند. secret و token هرگز نباید log شوند.
     */
    private generateTotpCode(otpAuthUri: string | null): string {
        if (!otpAuthUri?.trim()) {
            throw new Error("برای این اکانت 2fa_secret ثبت نشده است.");
        }

        let otp: OTPAuth.HOTP | OTPAuth.TOTP;
        try {
            otp = OTPAuth.URI.parse(otpAuthUri.trim());
        } catch {
            throw new Error("فرمت 2fa_secret این اکانت معتبر نیست.");
        }

        if (!(otp instanceof OTPAuth.TOTP)) {
            throw new Error("مقدار 2fa_secret باید یک URI از نوع otpauth://totp باشد.");
        }

        return otp.generate();
    }

    /** TODO: رمزگشایی پسورد ذخیره‌شده. فعلا فرض می‌کنیم plain است - باید با crypto جایگزین شود */
    private decryptPassword(encrypted: string): string {
        return encrypted; // FIXME: باید با یک الگوریتم واقعی (مثلا AES-256-GCM) جایگزین شود
    }
}
