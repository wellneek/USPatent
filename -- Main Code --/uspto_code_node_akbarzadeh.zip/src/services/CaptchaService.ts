import {Page} from "playwright";
import {LogRepository} from "../db/LogRepository";
import {askCliAttentionWithTimeout} from "../cli/prompt";
import {waitForElementReady, isElementVisibleSoon, safeClick} from "../utils/waitForElement";
import {findCachedAnswer, saveSolvedCaptcha, saveUnresolvedCaptcha} from "../utils/captchaCache";
import {MathOcrSolver, OcrSolveResult} from "./MathOcrSolver";
import {config} from "../config";
import * as process from "node:process";

const DIALOG_SELECTOR = "app-captcha-dialog";
const CANVAS_SELECTOR = `${DIALOG_SELECTOR} canvas.jCaptchaCanvas`;
const INPUT_SELECTOR = `${DIALOG_SELECTOR} input#jCaptcha`;
const CONTINUE_BUTTON_SELECTOR = `${DIALOG_SELECTOR} button[type="submit"]`;
const CANCEL_BUTTON_SELECTOR = `${DIALOG_SELECTOR} button:has-text("Cancel")`;

export type CaptchaOutcome = "solved" | "skipped";
type AnswerSource = "cache" | "ocr" | "cli" | "ocr-fallback" | "random-fallback";
const MAX_CACHE_FAILURES = 2;

export class CaptchaService {
    constructor(
        private logRepo: LogRepository,
        private ocrSolver: MathOcrSolver = new MathOcrSolver(parseInt(process.env.CAPTCHA_CONFIDENCE ?? "40")),
        private ocrAutoAcceptConfidence: number = config.captchaOcrAutoAcceptConfidence,
        private operatorWaitMs: number = config.captchaOperatorWaitMs
    ) {
    }

    async dispose(): Promise<void> {
        await this.ocrSolver.dispose();
    }

    async isDialogPresent(page: Page): Promise<boolean> {
        return isElementVisibleSoon(page, DIALOG_SELECTOR, 5000);
    }

    async resolveIfPresent(
        page: Page,
        urlId: number,
        fileId: number | null = null
    ): Promise<CaptchaOutcome> {
        if (!(await this.isDialogPresent(page))) {
            return "solved";
        }

        await this.logRepo.log(urlId, "CAPTCHA_DIALOG_DETECTED", "دیالوگ کپچا نمایش داده شد", "info", fileId);

        const MAX_ATTEMPTS = 10;
        let cacheFailures = 0;

        for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
            const canvasLocator = await waitForElementReady(page, CANVAS_SELECTOR, {
                description: "canvas کپچا",
                timeoutMs: 15000,
            });
            const screenshotBuffer = await canvasLocator.screenshot();

            let answer: string | null = null;
            let source: AnswerSource = "random-fallback";

            // ۱) کش
            if (cacheFailures < MAX_CACHE_FAILURES) {
                const cached = await findCachedAnswer(screenshotBuffer);
                if (cached) {
                    answer = cached.answer;
                    source = "cache";
                    await this.logRepo.log(
                        urlId, "CAPTCHA_CACHE_HIT",
                        `تصویر مشابه در کش پیدا شد؛ جواب: ${answer}`, "info", fileId
                    );
                }
            }

            // ۲) OCR - همیشه (در صورت تشخیص الگو) یک جواب با confidence برمی‌گرداند
            let ocrResult: OcrSolveResult | null = null;
            if (!answer) {
                ocrResult = await this.ocrSolver.solve(screenshotBuffer);

                if (ocrResult) {
                    await this.logRepo.log(
                        urlId, "CAPTCHA_OCR_ANSWER",
                        `OCR خواند: ${ocrResult.expression} = ${ocrResult.answer} (اطمینان ${ocrResult.confidence.toFixed(0)}%)`,
                        "info", fileId
                    );

                    if (ocrResult.confidence > this.ocrAutoAcceptConfidence) {
                        answer = ocrResult.answer;
                        source = "ocr";
                    }
                } else {
                    await this.logRepo.log(urlId, "CAPTCHA_OCR_UNSURE", "OCR نتوانست هیچ عبارتی بخواند", "info", fileId);
                }
            }

            // ۳) اطمینان OCR کم بود یا اصلا جوابی نداشت: با سقف زمانی منتظر اپراتور می‌مانیم
            if (!answer) {
                console.log(
                    `🧮 کپچا نمایش داده شد (تلاش ${attempt}/${MAX_ATTEMPTS}). ` +
                    `حداکثر ${Math.round(this.operatorWaitMs / 60000)} دقیقه منتظر اپراتور می‌مانیم؛ ` +
                    `در غیر این صورت جواب OCR/رندوم جایگزین می‌شود.`
                );

                const operatorAnswer = await askCliAttentionWithTimeout(
                    `جواب کپچا را وارد کن (یا 'skip' برای رد شدن) [تلاش ${attempt}/${MAX_ATTEMPTS}]`,
                    this.operatorWaitMs,
                    {
                        banner: ocrResult
                            ? `OCR با اطمینان کم (${ocrResult.confidence.toFixed(0)}%) حدس زد ${ocrResult.answer}؛ تصویر را در مرورگر ببین و تایید/اصلاح کن!`
                            : "OCR نتوانست کپچا را بخواند؛ تصویر را در مرورگر ببین و جواب را همین‌جا وارد کن!",
                    }
                );

                if (operatorAnswer !== null && operatorAnswer.toLowerCase() === "skip") {
                    const savedPath = await saveUnresolvedCaptcha(screenshotBuffer);
                    await this.logRepo.log(
                        urlId, "CAPTCHA_SKIPPED",
                        `کاربر از حل کپچا صرف‌نظر کرد. تصویر ذخیره شد: ${savedPath}`, "warning", fileId
                    );
                    await safeClick(page, CANCEL_BUTTON_SELECTOR, {description: "دکمه Cancel کپچا"}).catch(() => {});
                    return "skipped";
                }

                if (operatorAnswer !== null && operatorAnswer.length > 0) {
                    answer = operatorAnswer;
                    source = "cli";
                } else if (ocrResult) {
                    answer = ocrResult.answer;
                    source = "ocr-fallback";
                    await this.logRepo.log(
                        urlId, "CAPTCHA_OPERATOR_TIMEOUT_USING_OCR",
                        `اپراتور ظرف مهلت مقرر جواب نداد؛ از جواب OCR (اطمینان ${ocrResult.confidence.toFixed(0)}%) استفاده شد: ${answer}`,
                        "warning", fileId
                    );
                } else {
                    answer = String(Math.floor(Math.random() * 10) + 1);
                    source = "random-fallback";
                    await this.logRepo.log(
                        urlId, "CAPTCHA_OPERATOR_TIMEOUT_USING_RANDOM",
                        `اپراتور جواب نداد و OCR هم چیزی نخوانده بود؛ جواب تصادفی امتحان شد: ${answer}`,
                        "warning", fileId
                    );
                }
            }

            await page.fill(INPUT_SELECTOR, answer);
            await safeClick(page, CONTINUE_BUTTON_SELECTOR, {description: "دکمه Continue کپچا"});

            const isInvalid = await this.wasAnswerInvalid(page);

            if (!isInvalid) {
                if (source !== "cache") {
                    await saveSolvedCaptcha(screenshotBuffer, answer);
                }
                await this.logRepo.log(urlId, "CAPTCHA_SOLVED", `کپچا حل شد (منبع: ${source})`, "info", fileId);
                return "solved";
            }

            if (source === "cache") cacheFailures++;

            await this.logRepo.log(
                urlId, "CAPTCHA_INVALID_ANSWER",
                `جواب اشتباه بود (منبع: ${source}، تلاش ${attempt}). کپچای جدید نمایش داده شد.`,
                "warning", fileId
            );
        }

        await this.logRepo.log(
            urlId, "CAPTCHA_MAX_ATTEMPTS_REACHED", `بعد از ${MAX_ATTEMPTS} تلاش، کپچا حل نشد.`, "error", fileId
        );
        return "skipped";
    }

    private async wasAnswerInvalid(page: Page): Promise<boolean> {
        await page.waitForTimeout(800);
        const invalidInput = page.locator(`${INPUT_SELECTOR}.invalid`);
        if ((await invalidInput.count()) > 0) return true;
        const dialogStillOpen = await page.locator(DIALOG_SELECTOR).count();
        if (dialogStillOpen === 0) return false;
        return false;
    }

    async handleIfPresent(page: Page, urlId: number | null): Promise<void> {
        if (urlId == null) return;
        await this.resolveIfPresent(page, urlId, null);
    }
}