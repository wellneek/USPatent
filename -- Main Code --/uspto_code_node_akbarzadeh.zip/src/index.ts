import "dotenv/config";
import { firefox } from "playwright";
import fs from "fs/promises";

import {Database} from "./db/Database";
import {AccountRepository} from "./db/AccountRepository";
import {UrlRepository} from "./db/UrlRepository";
import {FileRepository} from "./db/FileRepository";
import {LogRepository} from "./db/LogRepository";

import {AuthService} from "./services/AuthService";
import {MathOcrSolver} from "./services/MathOcrSolver";
import {CaptchaService} from "./services/CaptchaService";
import {ScannerService} from "./services/ScannerService";
import {DownloadService} from "./services/DownloadService";
import {HealthCheckService} from "./services/HealthCheckService";
import {KeepAliveService} from "./services/KeepAliveService";
import {JobOrchestrator} from "./orchestrator/JobOrchestrator";
import {config} from "./config";
import {UsptoPageAdapter} from "./site/UsptoPageAdapter";
import {StopController, parseStopHours} from "./utils/StopController";

async function main() {
    // اگر STOP_HOURS نامعتبر باشد همین‌جا خطا می‌دهد (قبل از باز شدن مرورگر)
    const stopController = new StopController(parseStopHours(config.stopHours));
    stopController.installSignalHandlers();

    // خارج از ساعت مجاز: بدون باز کردن مرورگر/دیتابیس خارج شو
    // const initialStopReason = stopController.reason();
    // if (initialStopReason) {
    //     console.log(`⏸️ ${initialStopReason}؛ برنامه اجرا نمی‌شود.`);
    //     return;
    // }

        // خارج از ساعت مجاز: بدون باز کردن مرورگر/دیتابیس منتظر می‌مانیم تا زمان اجرا برسد.
    // اگر دلیل توقف سیگنال (کاربر Ctrl+C زده) باشد، بلافاصله خارج می‌شویم.
    const canProceed = await stopController.waitUntilRunnable();
    if (!canProceed) {
        return;
    }

    // --- دیتابیس ---
    const database = Database.getInstance();
    await database.pool.query("SELECT 1");
    await fs.mkdir(config.downloadDir, {recursive: true});

    const firefoxProfileDir = `${config.browserProfileDir}-firefox`;
    await fs.mkdir(firefoxProfileDir, { recursive: true });

    const accountRepo = new AccountRepository();
    const urlRepo = new UrlRepository();
    const fileRepo = new FileRepository();
    const logRepo = new LogRepository();

    await fs.mkdir(config.downloadDir, {recursive: true});
    await fs.mkdir(config.incomingDir, {recursive: true});

    const context = await firefox.launchPersistentContext(firefoxProfileDir, {
        executablePath: `${process.env.HOME}/.local/share/playwright/firefox-155/firefox`,
        headless: config.headless,
        acceptDownloads: true,
        downloadsPath: config.incomingDir,
        userAgent: config.customHeaders["User-Agent"],
        extraHTTPHeaders: config.customHeaders,
        viewport: { width: 1024, height: 768 },
        locale: "en-US",
        timeout: 60_000,
    });


    // const context = await chromium.launchPersistentContext(config.browserProfileDir, {
    //     headless: config.headless,
    //     acceptDownloads: true,
    //     downloadsPath: config.downloadDir,
    //
    //     // 👇 تغییرات جدید برای اعمال Agent و هدرها
    //     userAgent: config.customHeaders["User-Agent"],       // تغییر User-Agent در سطح موتور جاوااسکریپت (navigator.userAgent)
    //     extraHTTPHeaders: config.customHeaders,              // تزریق هدرها به تمام درخواست‌های شبکه (HTTP Requests)
    //
    //     // 👇 تنظیمات پیشنهادی تکمیلی برای طبیعی‌تر شدن رفتار مرورگر
    //     viewport: {width: 1280, height: 720},
    //     locale: 'en-US',
    //
    //     // timezoneId: 'America/New_York',
    //     // 👇 اضافه کردن آرگومان‌های ضروری برای لود اکستنشن
    //     // args: [
    //     //     `--disable-extensions-file-access-check`,
    //     //     // `--load-extension=${config.browserExtensionPath}`
    //     // ],
    // });
    //timezoneId: 'America/New_York', // یا هر تایم‌زون مرتبط با سرور/هدف شما
    // دریافت صفحه اول (که به طور خودکار در persistent context باز می‌شود) یا ساخت صفحه جدید
    const page = context.pages()[0] ?? await context.newPage();

    page.setDefaultTimeout(60_000);

    page.setDefaultNavigationTimeout(60_000);

    const site = new UsptoPageAdapter();
    const captchaService = new CaptchaService(logRepo, new MathOcrSolver(60));
    const authService = new AuthService(
        accountRepo,
        logRepo,
        captchaService,
        site,
        config.homeUrl
    );
    const scannerService = new ScannerService(captchaService, logRepo);
    const downloadService = new DownloadService(
        fileRepo,
        urlRepo,
        logRepo,
        captchaService,
        authService,
        {
            downloadDir: config.downloadDir,
            incomingDir: config.incomingDir,
            perFileTimeoutMs: config.perFileTimeoutMs,
            stallTimeoutMs: 10 * 60 * 1000,
            delayBetweenFilesMs: 5000,
        },
        stopController
    );
    const healthCheckService = new HealthCheckService(
        fileRepo,
        logRepo,
        config.healthToleranceBytes
    );
    const keepAliveService = new KeepAliveService(
        context,
        urlRepo,
        fileRepo,
        logRepo,
        config.keepAliveIntervalMs
    );

    const orchestrator = new JobOrchestrator(
        page,
        context,
        accountRepo,
        urlRepo,
        fileRepo,
        logRepo,
        authService,
        captchaService,
        scannerService,
        downloadService,
        healthCheckService,
        keepAliveService,
        config.jobPollIntervalMs,
        stopController
    );

    try {
        await orchestrator.run();
    } catch (e) {
        console.error("خطا در اجرای job:", e);
        process.exitCode = 1;
    } finally {
        await captchaService.dispose();
        await context.close();
        await database.close();
    }
}

main()
    .then(() => process.exit(process.exitCode ?? 0)) // handleهای باز (tesseract و ...) مانع خروج نشوند
    .catch((err) => {
        console.error("خطای کلی برنامه:", err);
        process.exit(1);
    });
