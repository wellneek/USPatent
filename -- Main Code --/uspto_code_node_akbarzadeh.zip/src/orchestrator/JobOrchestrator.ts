import {Page, BrowserContext} from "playwright";
import {AccountRepository} from "../db/AccountRepository";
import {UrlRepository} from "../db/UrlRepository";
import {FileRepository} from "../db/FileRepository";
import {LogRepository} from "../db/LogRepository";
import {AuthService} from "../services/AuthService";
import {CaptchaService} from "../services/CaptchaService";
import {ScannerService} from "../services/ScannerService";
import {DownloadService} from "../services/DownloadService";
import {HealthCheckService} from "../services/HealthCheckService";
import {KeepAliveService} from "../services/KeepAliveService";
import {StopController} from "../utils/StopController";
import {BrowserDiedError, PageLoadTimeoutError, isBrowserClosedError} from "../utils/browserErrors";
export class JobOrchestrator {
    constructor(
        private page: Page,
        private context: BrowserContext,
        private accountRepo: AccountRepository,
        private urlRepo: UrlRepository,
        private fileRepo: FileRepository,
        private logRepo: LogRepository,
        private authService: AuthService,
        private captchaService: CaptchaService,
        private scannerService: ScannerService,
        private downloadService: DownloadService,
        private healthCheckService: HealthCheckService,
        private keepAliveService: KeepAliveService,
        private jobPollIntervalMs: number = 30_000,
        private stopController: StopController = new StopController(null)
    ) {
    }

    async run(): Promise<void> {
        // اگر همین الان باید متوقف باشیم، اصلا لاگین نکن
        if (await this.shouldExit("شروع برنامه")) return;

        await this.recoverInterruptedState();
        await this.ensureLoggedIn();
        let shouldRecheckAuthentication = false;

        while (true) {
            // مرز امن ۱: قبل از برداشتن job بعدی (یا حالت idle)
            if (await this.shouldExit("قبل از job بعدی")) return;

            const job = await this.urlRepo.getNextRunnableJob();
            if (!job) {
                console.log(
                    `منتظر کار جدید... بررسی مجدد در ${Math.round(this.jobPollIntervalMs / 1000)} ثانیه`
                );
                shouldRecheckAuthentication = true;
                await this.waitForNextPoll();
                continue;
            }

            // ممکن است هنگام انتظار طولانی نشست logout شده باشد.
            if (shouldRecheckAuthentication) {
                await this.ensureLoggedIn();
                shouldRecheckAuthentication = false;
            }

            // شروع سرویس keep-alive قبل از شروع دانلود طولانی
            this.keepAliveService.start();

            try {
                await this.urlRepo.updateStatus(job.id, "scanning");
                const candidates = await this.scannerService.scan(this.page, job);

                await this.urlRepo.setFilesFoundCount(job.id, candidates.length);
                await this.fileRepo.registerScannedFiles(job.id, candidates);

                await this.urlRepo.updateStatus(job.id, "processing");
                const result = await this.downloadService.downloadPendingFiles(this.page, this.context, job);

                if (result === "stopped") {
                    // فایل‌های باقی‌مانده registered هستند؛ job به paused می‌رود تا دفعه‌ی بعد اول از همه ادامه یابد
                    await this.urlRepo.syncDownloadedFilesCount(job.id);
                    await this.urlRepo.updateStatus(job.id, "paused");
                    await this.logRepo.log(
                        job.id,
                        "JOB_PAUSED",
                        "job به‌خاطر توقف نرم متوقف شد (paused) و دفعه‌ی بعد با اولویت اول ادامه می‌یابد",
                        "warning"
                    );
                    return;
                }

                await this.urlRepo.updateStatus(job.id, "downloaded");

                // بررسی سلامت فایل‌های دانلود شده
                /*const pendingForHealthCheck = await this.fileRepo.getPendingFiles(job.id);
                // توجه: بعد از دانلود، فایل‌ها دیگر registered نیستند؛
                // در پیاده‌سازی نهایی یک متد repository برای گرفتن فایل‌های status='downloaded' اضافه کن.
                for (const file of pendingForHealthCheck) {
                    await this.healthCheckService.checkFile(file, job.id);
                }

                await this.urlRepo.updateStatus(job.id, "verified");
                */
                /*

                // بررسی سلامت فایل‌های دانلود شده
                const downloadedFiles = await this.fileRepo.getDownloadedFiles(job.id);
                for (const file of downloadedFiles) {
                    await this.healthCheckService.checkFile(file, job.id);
                }

                const afterHealthCheck = await this.fileRepo.getStatusCounts(job.id);
                const allHealthy =
                    afterHealthCheck.downloaded === 0 &&
                    afterHealthCheck.verified_healthy === candidates.length;
                if (allHealthy) {
                    await this.urlRepo.updateStatus(job.id, "verified");
                } else {
                    await this.logRepo.log(
                        job.id,
                        "JOB_HEALTH_CHECK_INCOMPLETE",
                        "حداقل یک فایل تأیید سلامت نشد؛ وضعیت URL روی downloaded باقی ماند.",
                        "warning"
                    );
                }

                 */


            } catch (error) {

                if (
                    error instanceof BrowserDiedError ||
                    error instanceof PageLoadTimeoutError ||
                    isBrowserClosedError(error)
                ) {
                    throw error; // برنامه خارج می‌شود تا runner پروفایل را پاک و دوباره اجرا کند
                }

                await this.logRepo.log(job.id, "JOB_ERROR", `پردازش URL متوقف شد: ${(error as Error).message}`, "error");
                // job شروع شده ولی تمام نشده؛ با اولویت اول دوباره امتحان شود
                await this.urlRepo.updateStatus(job.id, "paused");

                if (error instanceof BrowserDiedError || isBrowserClosedError(error)) {
                    throw error; // برنامه خارج می‌شود تا supervisor دوباره بالا بیاورد
                }
                await this.waitForNextPoll(); // جلوگیری از حلقه‌ی سریع روی خطاهای دیگر
            } finally {
                this.keepAliveService.stop();
            }
        }
    }

    /** انتظار به‌صورت تکه‌های ۱ ثانیه‌ای تا با رسیدن سیگنال/پایان پنجره سریع بیدار شویم */
    private async waitForNextPoll(): Promise<void> {
        const deadline = Date.now() + this.jobPollIntervalMs;
        while (Date.now() < deadline && !this.stopController.reason()) {
            await new Promise<void>((resolve) => setTimeout(resolve, Math.min(1000, deadline - Date.now())));
        }
    }

    private async shouldExit(where: string): Promise<boolean> {
        const reason = this.stopController.reason();
        if (!reason) return false;
        await this.logRepo.log(null, "APP_STOPPING", `خروج نرم (${where}): ${reason}`, "info");
        return true;
    }

    /**
     * اگر نمونه‌ی قبلی برنامه ناگهانی مرده باشد (kill -9، قطع برق، ...) jobها/فایل‌ها
     * در scanning/processing/downloading می‌مانند. چون cron با flock فقط یک نمونه
     * اجرا می‌کند، این ریست امن است.
     */
    private async recoverInterruptedState(): Promise<void> {
        const jobs = await this.urlRepo.resetInterruptedJobs();
        const files = await this.fileRepo.resetInterruptedDownloads();
        if (jobs > 0 || files > 0) {
            await this.logRepo.log(
                null,
                "RECOVERED_INTERRUPTED_STATE",
                `بازیابی بعد از توقف ناگهانی: ${jobs} job به paused و ${files} فایل به registered برگشت`,
                "warning"
            );
        }
    }

    /**
     * بررسی می‌کند که آیا از قبل لاگین هستیم؛ اگر نه، اکانتی با بالاترین اولویت
     * انتخاب کرده و فرآیند لاگین سه‌مرحله‌ای را اجرا می‌کند.
     */
    private async ensureLoggedIn(): Promise<void> {
        // تایید شده با inspect: صفحه اصلی هدری دارد که وضعیت لاگین از رویش قابل تشخیص است
        await this.page.goto(this.authService.homeUrl, {waitUntil: "networkidle"});

        if (await this.authService.isLoggedIn(this.page)) {
            console.log("✅ از قبل لاگین هستیم.");
            return;
        }

        const account = await this.accountRepo.pickNextAvailableAccount();
        if (!account) {
            throw new Error("هیچ اکانت فعالی برای لاگین پیدا نشد.");
        }

        // شماره url واقعی برای لاگ اینجا در دسترس نیست (هنوز job انتخاب نشده)
        // پس urlId را null می‌فرستیم که در جدول url_event_logs به‌عنوان رخداد عمومی سیستم ثبت می‌شود.
        const success = await this.authService.login(this.page, account, null);
        if (!success) {
            throw new Error(`لاگین با اکانت ${account.username} ناموفق بود.`);
        }
    }
}